### 服务器配置
```angular2html
40G的盘就够用了，空间不够的时候，可以清空chapter_execute表中now_state=2的数据
```



* mysql版本：8.0.40
* jdk版本：17
* node版本：v22.14.0
* vue版本：@vue/cli 5.0.8


* 在执行完data.sql之后，执行下面的命令
```angular2html
INSERT INTO novel.dictionary (id, key_field, value_field, description, is_deleted, created_at, updated_at) VALUES (45, 'novelPiaFont', 'false', 'false代表关闭反爬虫文本处理', 0, '2025-05-30 08:31:32', '2025-05-30 08:31:32');
```

* platform_api_key表用于存储Ai模型的apikey，目前仅支持硅基流动。
### 1、文件NotoSansKR-VariableFont_wght.ttf和文件obfuscatedNotoSansKR2.ttf的位置
* linux：/home/novel/file/
* window：C:\Users\80\Desktop\NTR\333\

### 2、CloudflareR2Util文件需要修改的地方
```java
    private static final String ACCOUNT_ID = "1695ffc38d5*****055757d56";
    private static final String ACCESS_KEY = "c87abd30bdc*****27f421abb0c3";
    private static final String SECRET_KEY = "85c2141304d1d1*****d931d238d6b9323b027b2eb";
    private static final String BUCKET_NAME = "photo";
    private static final String ENDPOINT = String.format("https://%s.r2.cloudflarestorage.com", ACCOUNT_ID);
    private static final Region REGION = Region.of("auto");
    private static final S3Client S3_CLIENT;
```
将上方代码块中的内容替换成真实的，就可以将novelPia中的插图上传到cloudflare的R2存储里面了，如果不希望启动cloudflare的R2存储，可以将表dictionary中的executePhoto改成false


### 3、前端打包命令
```vue
npm install
npm run build --no-source-map
```

### 4、表invitation_code里面存储的是邀请码，可以添加，但是不要修改。

### 5、URLMatcher类中的PATTERNS为无需登录便可以访问的接口