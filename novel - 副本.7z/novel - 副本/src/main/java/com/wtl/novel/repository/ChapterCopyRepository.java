package com.OPT.novel.repository;


import com.OPT.novel.entity.ChapterCopy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChapterCopyRepository extends JpaRepository<ChapterCopy, Long> {
}