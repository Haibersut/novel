package com.wtl.novel.repository;

import com.wtl.novel.entity.ChapterUpdate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChapterUpdateRepository extends JpaRepository<ChapterUpdate, Long> {
}
