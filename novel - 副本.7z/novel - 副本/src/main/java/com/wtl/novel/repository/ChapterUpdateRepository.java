package com.OPT.novel.repository;

import com.OPT.novel.entity.ChapterUpdate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChapterUpdateRepository extends JpaRepository<ChapterUpdate, Long> {
}
