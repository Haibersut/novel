package com.OPT.novel.DTO;

public interface SourceTargetProjection {
    String getSourceName();
    String getTargetName();
}