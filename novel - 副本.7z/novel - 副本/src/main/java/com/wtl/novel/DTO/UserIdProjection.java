package com.OPT.novel.DTO;

public interface UserIdProjection {
    Long getUserId();
}
