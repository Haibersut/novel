package com.wtl.novel.DTO;

public interface UserIdProjection {
    Long getUserId();
}
