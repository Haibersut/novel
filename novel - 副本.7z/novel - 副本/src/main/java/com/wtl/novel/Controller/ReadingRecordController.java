package com.wtl.novel.Controller;

import com.wtl.novel.Service.ReadingRecordService;
import com.wtl.novel.entity.ReadingRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reading-record")
public class ReadingRecordController {
}