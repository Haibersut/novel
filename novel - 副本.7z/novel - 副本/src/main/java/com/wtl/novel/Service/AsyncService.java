package com.OPT.novel.Service;

import com.OPT.novel.CDO.SyosetuNovelDetail;
import com.OPT.novel.entity.Novel;
import com.OPT.novel.translator.Novelpia;
import com.OPT.novel.translator.Syosetu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class AsyncService {

    @Autowired
    private Syosetu syosetu;

    @Autowired
    private Novelpia novelpia;


    @Async
    public void saveNovelAsync(String keyword, SyosetuNovelDetail syosetuNovelDetail, Novel save) {
        try {
            syosetu.saveNovel(keyword, syosetuNovelDetail, save);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Async
    public void saveNovelPiaAsync(String keyword, SyosetuNovelDetail syosetuNovelDetail, Novel save) {
        try {
            novelpia.saveNovel(keyword, syosetuNovelDetail, save);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}