package com.wtl.novel.DTO;

public record NovelSimpleDto(Long id, String title, String trueId) {}