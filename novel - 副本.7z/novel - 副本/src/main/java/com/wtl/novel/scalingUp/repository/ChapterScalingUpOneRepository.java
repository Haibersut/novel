package com.OPT.novel.scalingUp.repository;


import com.OPT.novel.scalingUp.entity.ChapterScalingUpOne;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ChapterScalingUpOneRepository extends JpaRepository<ChapterScalingUpOne, Long> {
    @Transactional
    @Modifying
    @Query("DELETE FROM ChapterScalingUpOne c WHERE c.novelId = :novelId")
    void deleteByNovelId(@Param("novelId") Long novelId);
}