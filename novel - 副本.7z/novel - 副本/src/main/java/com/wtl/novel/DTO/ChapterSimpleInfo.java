package com.wtl.novel.DTO;

public interface ChapterSimpleInfo {
    String getTitle();
    Integer getChapterNumber();
}