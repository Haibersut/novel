package com.OPT.novel.DTO;

public interface ChapterSimpleInfo {
    String getTitle();
    Integer getChapterNumber();
}