package com.OPT.novel.DTO;

public interface TextNumCount {
    Integer getTextNum();
    Long getCnt();
}