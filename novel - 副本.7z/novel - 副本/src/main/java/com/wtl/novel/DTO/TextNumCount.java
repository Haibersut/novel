package com.wtl.novel.DTO;

public interface TextNumCount {
    Integer getTextNum();
    Long getCnt();
}