package com.OPT.novel.siteMap;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.core.env.Environment;

//@Component
public class SiteMapJob {
//
//    @Autowired
//    private JdbcTemplate jdbcTemplate;
//
//    @Autowired
//    private Environment environment;
//
//    @PostConstruct
//    public void generateSitemap() {
//        boolean run = Boolean.parseBoolean(environment.getProperty("siteMap.run"));
//        if (run) {
//            //执行逻辑
//        }
//    }
}