package com.OPT.novel.repository;

import com.OPT.novel.entity.NovelDownloadLimit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NovelDownloadLimitRepository extends JpaRepository<NovelDownloadLimit, Long> {
}