package com.OPT.novel.Controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reading-record")
public class ReadingRecordController {
}