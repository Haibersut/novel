package com.OPT.novel.repository;

import com.OPT.novel.entity.UserAccessLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface UserAccessLogRepository extends JpaRepository<UserAccessLog, Long> {
    List<UserAccessLog> findByUserIdAndVisitDate(Long userId, LocalDate date);
}